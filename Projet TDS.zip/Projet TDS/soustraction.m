i=imread('3-1.png');
j=imread('3-2.png');
figure,imshow(j-i);